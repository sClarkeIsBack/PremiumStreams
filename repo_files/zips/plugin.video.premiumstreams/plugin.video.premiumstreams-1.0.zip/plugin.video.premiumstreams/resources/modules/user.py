import base64 as b
import xbmcaddon

id   = 'plugin.video.premiumstreams'

name = b.b64decode('UHJlbWl1bSBTdHJlYW1z')

host = b.b64decode('aHR0cDovL3N0cmVhbWh1YnByZW1pdW0uZGRucy5uZXQ=')

port = b.b64decode('NDU0NQ==')